# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

This is a Ghost theme called "basify" - a minimalistic, free theme for the Ghost blogging platform. The theme targets Ghost >= 5.0.0 and follows a simple, clean design philosophy.

## Development Commands

**Build and Development:**
- `npm run dev` or `gulp` - Start development mode with file watching and live reload
- `gulp build` - Build CSS and JS assets for production
- `npm run zip` or `gulp zip` - Create a distributable theme zip file in `dist/`

**Testing:**
- `npm test` or `gscan .` - Test theme compatibility with Ghost
- `npm run test:ci` or `gscan --fatal --verbose .` - CI-friendly testing with verbose output

**Release Process:**
- `npm run ship` - Version bump and push with tags (requires clean working tree)
- `gulp release` - Create GitHub release draft with changelog

## Architecture

**Template Structure:**
- `default.hbs` - Main layout template with header, navigation, content area, and footer
- `index.hbs` - Homepage template extending default layout
- Templates use Handlebars syntax with Ghost-specific helpers

**Asset Pipeline:**
- Source assets in `assets/css/` and `assets/js/`
- Built assets output to `assets/built/`
- CSS processing: PostCSS with autoprefixer, color functions, and cssnano
- JS processing: Concatenation and uglification
- Sourcemaps generated for both CSS and JS

**Build System:**
- Uses Gulp 5 with modern ES modules
- Watches for changes in `.hbs`, CSS, and JS files
- Live reload functionality for development
- Modular task structure with error handling

**Theme Configuration:**
- Supports Ghost's color scheme settings (Dark/Auto modes)
- Logo and cover image support
- Navigation (primary and secondary) integration
- Compatible with Ghost's pagination system

## File Structure Notes

- No partials directory exists yet - all templates are top-level
- Assets are processed from source directories to `built/` folder
- Theme packaging excludes development files (node_modules, gulpfile, etc.)